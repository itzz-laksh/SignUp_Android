package com.example.signup;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.text.TextUtils;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    EditText Username;
    EditText email;
    EditText Password;
    EditText ConfirmPassword;
    Button button;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Username = findViewById(R.id.Username);
        email = findViewById(R.id.email);
        Password = findViewById(R.id.Password);
        ConfirmPassword = findViewById(R.id.ConfirmPassword);
        button = findViewById(R.id.button);

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                checkDataEntered();
            }
        });
    }
    boolean isEmail(EditText text) {
        CharSequence email = text.getText().toString();
        return (!TextUtils.isEmpty(email) && Patterns.EMAIL_ADDRESS.matcher(email).matches());
    }

    boolean isEmpty(EditText text) {
        CharSequence str = text.getText().toString();
        return TextUtils.isEmpty(str);
    }

    void checkDataEntered() {
        if (isEmpty(Username)) {
            Toast t1 = Toast.makeText(this, "You must enter Name to register!", Toast.LENGTH_SHORT);
            t1.show();
        }

        if (isEmail(email) == false) {
            email.setError("Enter valid email!");
        }

        if (isEmpty(Password)) {
            Toast t2 = Toast.makeText(this, "You must enter Password to register!", Toast.LENGTH_SHORT);
            t2.show();
        }

        if (isEmpty(ConfirmPassword)) {
            Toast t3 = Toast.makeText(this, "You must enter Confirn Password to register!", Toast.LENGTH_SHORT);
            t3.show();
        }

    }
}
